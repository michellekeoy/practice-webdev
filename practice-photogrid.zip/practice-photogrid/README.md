# sample-photogrid

This is practice for using the grid system from Bootstrap.
